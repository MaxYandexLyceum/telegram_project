import json


def get_data(id):
    with open('izbrannie.json') as f:
        data = json.load(f)
    return data["users"][str(id)]
