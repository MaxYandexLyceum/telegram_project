from bs4 import BeautifulSoup
import requests

sources = ["https://www.igromania.ru/news/", "https://stopgame.ru/news", "https://gamemag.ru/news"]


def get_data_from_igromania():
    response = requests.get(sources[0])
    soup = BeautifulSoup(response.text, "xml")
    quotes = list([str(i) for i in list(soup.find_all('img'))][1:])[:7]
    data = []
    for i in quotes:
        data.append(i[i.find("alt=") + 5:i.find("src") - 2])
    quotes1 = [str(i) for i in list(soup.find_all('a', class_='aubli_name'))][:7]
    data1 = ["https://www.igromania.ru/" + i[i.find("href") + 6:i.find("html") + 4] for i in quotes1]
    ans = []
    for i in range(len(data)):
        try:
            ans.append([data[i], data1[i]])
        except IndexError:
            pass
    return ans


def get_data_from_stopgame():
    response = requests.get(sources[1])
    soup = BeautifulSoup(response.text, "xml")
    quotes = list([str(i) for i in list(soup.find_all('div', class_="caption caption-bold"))][:3])
    data = []
    data1 = []
    for i in quotes:
        data.append(i[i.find('newsdata') + 16:i.rfind("a") - 2])
        data1.append("https://stopgame.ru" + i[i.find('hre') + 6:i.find('href=') + 21])
    ans = []
    for i in range(len(data)):
        ans.append([data[i], data1[i]])
    return ans


def get_data_from_gamemag():
    response = requests.get(sources[2])
    soup = BeautifulSoup(response.text, "xml")
    quotes = list([str(i) for i in list(soup.find_all('a', class_="news-item__text"))])[0:3]
    data = []
    data1 = []
    for i in quotes:
        data.append(i[i.find('>') + 1:i.rfind("/a") - 1])
        data1.append("https://gamemag.ru" + i[i.find('href') + 6:i.find('>') - 1])
    ans = []
    for i in range(len(data)):
        ans.append([data[i], data1[i]])
    return ans
