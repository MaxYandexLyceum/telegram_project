import json


def deletesubscriber(id):
    with open('subscribers.json') as f:
        data = json.load(f)

    data["users"][str(id)] = False

    with open('subscribers.json', 'w') as f:
        json.dump(data, f)
