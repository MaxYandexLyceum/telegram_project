import json


def delete_data(id):
    with open('izbrannie.json') as f:
        data = json.load(f)
    try:
        data["users"][str(id)] = []
    except Exception:
        pass
    with open('izbrannie.json', 'w') as f:
        json.dump(data, f)
