import json


def task_json(id, izbrannie):
    with open('izbrannie.json') as f:
        data = json.load(f)
    if id not in data["users"]:
        data["users"][str(id)] = izbrannie
    else:
        for i in izbrannie:
            if i not in data["users"][str(id)]:
                data["users"][str(id)].append(i)
        # data["users"][str(id)] = data["users"][str(id)] + izbrannie
    # data["users"][str(id)] = list(set(data["users"][str(id)]))
    with open('izbrannie.json', 'w') as f:
        json.dump(data, f)
