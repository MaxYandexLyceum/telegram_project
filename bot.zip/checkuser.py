import json


def checksubscriber(id):
    with open('subscribers.json') as f:
        data = json.load(f)
    try:
        if data["users"][str(id)]:
            return True
    except Exception:
        return False
    return False
