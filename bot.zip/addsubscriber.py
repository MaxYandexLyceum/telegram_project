import json


def addsubscriber(id):
    with open('subscribers.json') as f:
        data = json.load(f)
    try:
        if data["users"][str(id)]:
            return False
        data["users"][str(id)] = True
    except Exception:
        data["users"][str(id)] = True

    with open('subscribers.json', 'w') as f:
        json.dump(data, f)
    return True
