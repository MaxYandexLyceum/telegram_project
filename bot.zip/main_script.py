import json
import random
import time

import telebot
from telebot import types
import threading

from get_data_from_json import get_data
from secretToken import TOKEN
from parsing import get_data_from_igromania
from parsing import get_data_from_stopgame
from parsing import get_data_from_gamemag
from file_manager_json import task_json
from delete_all_izbrannie import delete_data
from addsubscriber import addsubscriber
from deletesubscriber import deletesubscriber
from checkuser import checksubscriber

import schedule
import time

bot = telebot.TeleBot(TOKEN)

izbrannie = []
data = get_data_from_igromania()
data1 = get_data_from_stopgame()
data2 = get_data_from_gamemag()
urls = [*[i[1] for i in data], *[i[1] for i in data1], *[i[1] for i in data2]]
d = {}
unsubscribe = False


@bot.callback_query_handler(func=lambda call: True)
def callback_worker(call):
    global izbrannie
    global mmm
    global unsubscribe
    global hodi
    global xxx
    global y
    global z
    global current

    data = get_data_from_igromania()
    data1 = get_data_from_stopgame()
    data2 = get_data_from_gamemag()
    urls = [*[i[1] for i in data], *[i[1] for i in data1], *[i[1] for i in data2]]

    a = call.data.split(",")
    if "izbrannoe" in call.data:
        izbrannie.append(urls[int(a[2])])
        id = a[1]
        if len(id) < 9:
            pass
        task_json(id, izbrannie)
        bot.answer_callback_query(callback_query_id=call.id, text='Новость успешно добавлена в избранное')
    if "YES" in call.data:
        unsubscribe = True
        a = call.data.split(",")
        deletesubscriber(a[1])
        bot.answer_callback_query(callback_query_id=call.id, text='Вы успешно отписалсиь')
        bot.send_sticker(a[1], "CAACAgIAAxkBAAECM7FgfX1lxQiV6ubmipLt8uv7R6TolQAC4TcAAulVBRjQ3WdHoSDfPR8E")
    elif "NO" in call.data:
        unsubscribe = False
        bot.answer_callback_query(callback_query_id=call.id, text='Вы всё ещё подписаны!')
    if "nim" in call.data:
        # print(y)
        # print(z)
        # print(xxx + a[1])
        try:
            if xxx + int(a[1]) == 0:
                bot.send_message(a[2], "Вы выиграли!!!")
                bot.send_sticker(a[2], "CAACAgIAAxkBAAECN5tggeMk9ighCgwPEoXFY2TBfFpcigAC-UgAAulVBRiWcLIrxIoxgh8E")
                xxx = random.randint(10, 100)
                y = random.randint(1, 20)
                z = random.randint(1, 20)
                z *= -1
                hodi = 10

                return
            elif hodi == 1:
                bot.send_message(a[2], "Вы проиграли(((")
                bot.send_sticker(a[2], "CAACAgIAAxkBAAECN51ggeM63oWkKi1zRG3_vJA1qTq6xQAC80gAAulVBRg4jCMYbCLxPh8E")
                xxx = random.randint(10, 50)
                y = random.randint(1, 20)
                z = random.randint(1, 20)
                z *= -1
                hodi = 10

                return

            hodi -= 1
            xxx += int(a[1])

            keyboard = types.InlineKeyboardMarkup()
            key = types.InlineKeyboardButton(text="+" + str(y),
                                             callback_data=f'nim,{y},{a[2]}')
            key1 = types.InlineKeyboardButton(text=str(z),
                                              callback_data=f'nim,{z},{a[2]}')
            keyboard.row(key)
            keyboard.row(key1)

            bot.send_message(a[2], f"Сейчас число: {xxx}, ходов осталось: {hodi}", reply_markup=keyboard)
        except Exception:
            return
    if "krest" in call.data:
        if mmm[int(a[1])][int(a[2])] == "⬜":
            mmm[int(a[1])][int(a[2])] = current
            if current == "X":
                current = "0"
            else:
                current = "X"
            if mmm[0][0] == mmm[0][1] == mmm[0][2] != "⬜" or mmm[1][0] == mmm[1][1] == mmm[1][2] != "⬜" or mmm[2][0] == \
                    mmm[2][1] == mmm[2][2] != "⬜":
                keyboard = types.InlineKeyboardMarkup()
                key = types.InlineKeyboardButton(text=mmm[0][0],
                                                 callback_data=f'krest,0,0,{a[3]}')
                key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                                  callback_data=f'krest,0,1,{a[3]}')
                key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                                  callback_data=f'krest,0,2,{a[3]}')
                key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                                  callback_data=f'krest,1,0,{a[3]}')
                key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                                  callback_data=f'krest,1,1,{a[3]}')
                key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                                  callback_data=f'krest,1,2,{a[3]}')
                key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                                  callback_data=f'krest,2,0,{a[3]}')
                key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                                  callback_data=f'krest,2,1,{a[3]}')
                key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                                  callback_data=f'krest,2,2,{a[3]}')
                keyboard.row(key, key1, key2)
                keyboard.row(key3, key4, key5)
                keyboard.row(key6, key7, key8)

                if current == "X":
                    bot.send_message(a[3], f"0 победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3], "CAACAgIAAxkBAAECOP1ggr9AZXEu7DmXVToBk2n-SeguPgAC_EgAAulVBRgTqKmpPrzsSB8E")
                else:
                    bot.send_message(a[3], f"X победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3], "CAACAgIAAxkBAAECOPtggr8MPK_Ry_mRlD160bHmv0wt0gAC-0gAAulVBRiO_0ybZrAl8R8E")
                return
            if mmm[0][0] == mmm[1][0] == mmm[2][0] != "⬜" or mmm[0][1] == mmm[1][1] == mmm[2][1] != "⬜" or mmm[0][2] == \
                    mmm[1][2] == mmm[2][2] != "⬜":
                keyboard = types.InlineKeyboardMarkup()
                key = types.InlineKeyboardButton(text=mmm[0][0],
                                                 callback_data=f'krest,0,0,{a[3]}')
                key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                                  callback_data=f'krest,0,1,{a[3]}')
                key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                                  callback_data=f'krest,0,2,{a[3]}')
                key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                                  callback_data=f'krest,1,0,{a[3]}')
                key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                                  callback_data=f'krest,1,1,{a[3]}')
                key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                                  callback_data=f'krest,1,2,{a[3]}')
                key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                                  callback_data=f'krest,2,0,{a[3]}')
                key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                                  callback_data=f'krest,2,1,{a[3]}')
                key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                                  callback_data=f'krest,2,2,{a[3]}')
                keyboard.row(key, key1, key2)
                keyboard.row(key3, key4, key5)
                keyboard.row(key6, key7, key8)

                if current == "X":
                    bot.send_message(a[3], f"0 победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3], "CAACAgIAAxkBAAECOP1ggr9AZXEu7DmXVToBk2n-SeguPgAC_EgAAulVBRgTqKmpPrzsSB8E")
                else:
                    bot.send_message(a[3], f"X победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3], "CAACAgIAAxkBAAECOPtggr8MPK_Ry_mRlD160bHmv0wt0gAC-0gAAulVBRiO_0ybZrAl8R8E")
                return
            if mmm[0][0] == mmm[1][1] == mmm[2][2] != "⬜" or mmm[0][2] == mmm[1][1] == mmm[2][0] != "⬜":
                keyboard = types.InlineKeyboardMarkup()
                key = types.InlineKeyboardButton(text=mmm[0][0],
                                                 callback_data=f'krest,0,0,{a[3]}')
                key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                                  callback_data=f'krest,0,1,{a[3]}')
                key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                                  callback_data=f'krest,0,2,{a[3]}')
                key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                                  callback_data=f'krest,1,0,{a[3]}')
                key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                                  callback_data=f'krest,1,1,{a[3]}')
                key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                                  callback_data=f'krest,1,2,{a[3]}')
                key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                                  callback_data=f'krest,2,0,{a[3]}')
                key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                                  callback_data=f'krest,2,1,{a[3]}')
                key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                                  callback_data=f'krest,2,2,{a[3]}')
                keyboard.row(key, key1, key2)
                keyboard.row(key3, key4, key5)
                keyboard.row(key6, key7, key8)

                if current == "X":
                    bot.send_message(a[3], f"0 победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3], "CAACAgIAAxkBAAECOP1ggr9AZXEu7DmXVToBk2n-SeguPgAC_EgAAulVBRgTqKmpPrzsSB8E")
                else:
                    bot.send_message(a[3], f"X победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3], "CAACAgIAAxkBAAECOPtggr8MPK_Ry_mRlD160bHmv0wt0gAC-0gAAulVBRiO_0ybZrAl8R8E")
                return
        if "⬜" not in mmm[0] and "⬜" not in mmm[1] and "⬜" not in mmm[2]:
            keyboard = types.InlineKeyboardMarkup()
            key = types.InlineKeyboardButton(text=mmm[0][0],
                                             callback_data=f'krest,0,0,{a[3]}')
            key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                              callback_data=f'krest,0,1,{a[3]}')
            key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                              callback_data=f'krest,0,2,{a[3]}')
            key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                              callback_data=f'krest,1,0,{a[3]}')
            key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                              callback_data=f'krest,1,1,{a[3]}')
            key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                              callback_data=f'krest,1,2,{a[3]}')
            key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                              callback_data=f'krest,2,0,{a[3]}')
            key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                              callback_data=f'krest,2,1,{a[3]}')
            key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                              callback_data=f'krest,2,2,{a[3]}')
            keyboard.row(key, key1, key2)
            keyboard.row(key3, key4, key5)
            keyboard.row(key6, key7, key8)
            bot.send_message(a[3], f"Ничья!", reply_markup=keyboard)
            bot.send_sticker(a[3], "CAACAgIAAxkBAAECOP9ggsZNovYbbxRF6orQIFX3ssqEOgAC9EgAAulVBRiOWmtxiz5tsh8E")
            return

        while True:
            i = random.randint(0, 2)
            j = random.randint(0, 2)
            if mmm[i][j] == "⬜":
                mmm[i][j] = "0"
                bot.send_message(a[3], "Компьютер походил")

                if mmm[0][0] == mmm[0][1] == mmm[0][2] != "⬜" or mmm[1][0] == mmm[1][1] == mmm[1][2] != "⬜" or mmm[2][
                    0] == \
                        mmm[2][1] == mmm[2][2] != "⬜":
                    keyboard = types.InlineKeyboardMarkup()
                    key = types.InlineKeyboardButton(text=mmm[0][0],
                                                     callback_data=f'krest,0,0,{a[3]}')
                    key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                                      callback_data=f'krest,0,1,{a[3]}')
                    key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                                      callback_data=f'krest,0,2,{a[3]}')
                    key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                                      callback_data=f'krest,1,0,{a[3]}')
                    key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                                      callback_data=f'krest,1,1,{a[3]}')
                    key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                                      callback_data=f'krest,1,2,{a[3]}')
                    key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                                      callback_data=f'krest,2,0,{a[3]}')
                    key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                                      callback_data=f'krest,2,1,{a[3]}')
                    key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                                      callback_data=f'krest,2,2,{a[3]}')
                    keyboard.row(key, key1, key2)
                    keyboard.row(key3, key4, key5)
                    keyboard.row(key6, key7, key8)
                    bot.send_message(a[3], f"0 победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3],
                                     "CAACAgIAAxkBAAECOP1ggr9AZXEu7DmXVToBk2n-SeguPgAC_EgAAulVBRgTqKmpPrzsSB8E")
                    return
                if mmm[0][0] == mmm[1][0] == mmm[2][0] != "⬜" or mmm[0][1] == mmm[1][1] == mmm[2][1] != "⬜" or mmm[0][
                    2] == \
                        mmm[1][2] == mmm[2][2] != "⬜":
                    keyboard = types.InlineKeyboardMarkup()
                    key = types.InlineKeyboardButton(text=mmm[0][0],
                                                     callback_data=f'krest,0,0,{a[3]}')
                    key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                                      callback_data=f'krest,0,1,{a[3]}')
                    key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                                      callback_data=f'krest,0,2,{a[3]}')
                    key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                                      callback_data=f'krest,1,0,{a[3]}')
                    key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                                      callback_data=f'krest,1,1,{a[3]}')
                    key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                                      callback_data=f'krest,1,2,{a[3]}')
                    key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                                      callback_data=f'krest,2,0,{a[3]}')
                    key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                                      callback_data=f'krest,2,1,{a[3]}')
                    key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                                      callback_data=f'krest,2,2,{a[3]}')
                    keyboard.row(key, key1, key2)
                    keyboard.row(key3, key4, key5)
                    keyboard.row(key6, key7, key8)
                    bot.send_message(a[3], f"0 победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3],
                                     "CAACAgIAAxkBAAECOP1ggr9AZXEu7DmXVToBk2n-SeguPgAC_EgAAulVBRgTqKmpPrzsSB8E")
                    return
                if mmm[0][0] == mmm[1][1] == mmm[2][2] != "⬜" or mmm[0][2] == mmm[1][1] == mmm[2][0] != "⬜":
                    keyboard = types.InlineKeyboardMarkup()
                    key = types.InlineKeyboardButton(text=mmm[0][0],
                                                     callback_data=f'krest,0,0,{a[3]}')
                    key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                                      callback_data=f'krest,0,1,{a[3]}')
                    key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                                      callback_data=f'krest,0,2,{a[3]}')
                    key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                                      callback_data=f'krest,1,0,{a[3]}')
                    key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                                      callback_data=f'krest,1,1,{a[3]}')
                    key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                                      callback_data=f'krest,1,2,{a[3]}')
                    key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                                      callback_data=f'krest,2,0,{a[3]}')
                    key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                                      callback_data=f'krest,2,1,{a[3]}')
                    key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                                      callback_data=f'krest,2,2,{a[3]}')
                    keyboard.row(key, key1, key2)
                    keyboard.row(key3, key4, key5)
                    keyboard.row(key6, key7, key8)
                    bot.send_message(a[3], f"0 победил!!!", reply_markup=keyboard)
                    bot.send_sticker(a[3],
                                     "CAACAgIAAxkBAAECOP1ggr9AZXEu7DmXVToBk2n-SeguPgAC_EgAAulVBRgTqKmpPrzsSB8E")
                    return


                current = "X"
                break
        keyboard = types.InlineKeyboardMarkup()
        key = types.InlineKeyboardButton(text=mmm[0][0],
                                         callback_data=f'krest,0,0,{a[3]}')
        key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                          callback_data=f'krest,0,1,{a[3]}')
        key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                          callback_data=f'krest,0,2,{a[3]}')
        key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                          callback_data=f'krest,1,0,{a[3]}')
        key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                          callback_data=f'krest,1,1,{a[3]}')
        key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                          callback_data=f'krest,1,2,{a[3]}')
        key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                          callback_data=f'krest,2,0,{a[3]}')
        key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                          callback_data=f'krest,2,1,{a[3]}')
        key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                          callback_data=f'krest,2,2,{a[3]}')
        keyboard.row(key, key1, key2)
        keyboard.row(key3, key4, key5)
        keyboard.row(key6, key7, key8)
        bot.send_message(a[3], "Ходи!", reply_markup=keyboard)


@bot.message_handler(commands=['getnews'])
def getnews(message):
    global izbrannie
    global d

    bot.send_message(message.from_user.id, "Загружаем данные...")
    bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECMmtge047FAdSgS42DlEJWdfT6AABk_gAAhhIAALpVQUY7ctc5ve0THkfBA")
    data = get_data_from_igromania()
    data1 = get_data_from_stopgame()
    data2 = get_data_from_gamemag()

    k = 0

    bot.send_message(message.from_user.id, "Последние новости из ресурса https://www.igromania.ru/news/")
    for i in data:
        bot.send_message(message.from_user.id, i[0])

        keyboard = types.InlineKeyboardMarkup()
        key = types.InlineKeyboardButton(text='Добавить в избранное',
                                         callback_data=f'izbrannoe,{message.from_user.id},{k}')
        keyboard.row(key)

        bot.send_message(message.from_user.id, "Подробнее: \n" + i[1], reply_markup=keyboard)
        k += 1

    bot.send_message(message.from_user.id, "Последние новости из ресурса https://stopgame.ru/news")
    for i in data1:
        bot.send_message(message.from_user.id, i[0])

        keyboard = types.InlineKeyboardMarkup()
        key = types.InlineKeyboardButton(text='Добавить в избранное',
                                         callback_data=f'izbrannoe,{message.from_user.id},{k}')
        keyboard.row(key)

        bot.send_message(message.from_user.id, "Подробнее: \n" + i[1], reply_markup=keyboard)
        k += 1

    bot.send_message(message.from_user.id, "Последние новости из ресурса https://gamemag.ru/news")
    for i in data2:
        bot.send_message(message.from_user.id, i[0])

        keyboard = types.InlineKeyboardMarkup()
        key = types.InlineKeyboardButton(text='Добавить в избранное',
                                         callback_data=f'izbrannoe,{message.from_user.id},{k}')
        keyboard.row(key)

        bot.send_message(message.from_user.id, "Подробнее: \n" + i[1], reply_markup=keyboard)
        k += 1


@bot.message_handler(commands=['subscribe'])
def subscribe(message):
    if addsubscriber(str(message.from_user.id)):
        bot.send_message(message.chat.id, "Вы успешно подписались на нашу рассылку новостей!")
        bot.send_message(message.chat.id, "Рассылка проходит каждые 12 часов")
        bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECM69gfXo5i16E4UWgocpKk2Jst8yaqgAC4DcAAulVBRihIvNOGhKHxB8E")
        # p1 = Process(target=lambda x: check_send_messages("1 0", str(message.from_user.id)), args=())
        # p1.start()
    else:
        bot.send_message(message.chat.id, "Вы уже итак подписаны!")
        bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECM7NgfX7HNztKIhfonej-Y6-vlJRXwwAC5TcAAulVBRi2IA1rxOaONR8E")


# @bot.message_handler(commands=['settimer'], content_types=['text'])
# def settimer(message):
#    id = message.from_user.id
#    msg = message.text
#    k = int(msg.split(" ")[1]) * 3600 + int(msg.split(" ")[2]) * 60


@bot.message_handler(commands=['unsubscribe'])
def unsubscribe(message):
    global unsubscribe

    if not checksubscriber(message.chat.id):
        bot.send_message(message.chat.id, "Вы итак не подписаны")
        bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECM7VgfYBDN9v6-MdJbr6KPwc3Y_ogVgAC0DcAAulVBRhLUnfa6CZG5x8E")
    else:
        keyboard = types.InlineKeyboardMarkup()
        key = types.InlineKeyboardButton(text='Да',
                                         callback_data=f'YES,{message.chat.id}')
        key1 = types.InlineKeyboardButton(text='Нет',
                                          callback_data='NO')
        keyboard.row(key)
        keyboard.row(key1)

        bot.send_message(message.chat.id, "Вы уверены, что хотите отписаться?", reply_markup=keyboard)

        # if unsubscribe:
        #    bot.send_message(message.chat.id, "Вы успешно отписались!",)
        #    bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECM7FgfX1lxQiV6ubmipLt8uv7R6TolQAC4TcAAulVBRjQ3WdHoSDfPR8E")
        #    deletesubscriber(str(message.chat.id))

        # addsubscriber(str(message.from_user.id))


@bot.message_handler(commands=['help'])
def help(message):
    bot.send_message(message.from_user.id, "Я Телеграм Бот GameJournal - игровой журнал!\n"
                                           "Что ты можешь здесь найти?\n"""
                                           "1) Подписаться на нашу рассылку и получать "
                                           "актуальные новости из игровой индустрии каждые 12 часов"
                                           " (команды /subscribe | /unsubscribe)\n"
                                           "2) Получить все новости (есть возможность"
                                           " добавления избранных новостей!) (/getnews)\n"
                                           "3) Получить/Очистить список избранных новостей"
                                           " (/getmyizbrannie | /deletemyizbrannie)\n"
                                           "4) Поиграть в наши встроенные мини-ингры!"
                                           "(/minigames)")
    bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECMmdge0NTRQjAiF8rD7IqrbBou4xDgQACtgkAAnlc4gnGTnKNypclSB8E")


@bot.message_handler(commands=['getmyizbrannie'])
def myizbrannie(message):
    data = get_data(message.from_user.id)

    if len(data) == 0:
        bot.send_message(message.from_user.id, "Здесь пока пусто(")
        bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECMsNge-xZqFvOL6MvuwY1k0i2huMAAUgAAlQLAAJ9-chI8TwmYs8rl2cfBA")
    else:
        bot.send_message(message.from_user.id, "Список твоих избранных новостей:\n")
        for i in data:
            bot.send_message(message.from_user.id, i)


@bot.message_handler(commands=['deletemyizbrannie'])
def delete_myizbrannie(message):
    global izbrannie

    bot.send_message(message.from_user.id, "Ваш список избранных успешно очищен!")
    izbrannie = []
    delete_data(message.from_user.id)


@bot.message_handler(commands=['start'])
def start(message):
    bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECMl1gey30yO99kd84G1zO9xu6IsjK2AACqQkAAnlc4gkW68sz_f3XOh8E")
    keyboard = telebot.types.ReplyKeyboardMarkup(True, one_time_keyboard=True)
    keyboard.row('/help')
    keyboard.row('/getnews')
    keyboard.row('/getmyizbrannie')
    keyboard.row('/deletemyizbrannie')
    keyboard.row('/subscribe')
    keyboard.row('/unsubscribe')
    keyboard.row('/minigames')
    bot.send_message(message.from_user.id, "Привет! Вот мои основные команды", reply_markup=keyboard)


@bot.message_handler(commands=['minigames'])
def minigames(message):
    bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAECNBlgfernXqUMAybroR0bZ0Drawm9ZwACQQEAAorsmwiLeS10pYNrwR8E")
    keyboard = telebot.types.ReplyKeyboardMarkup(True, one_time_keyboard=True)
    keyboard.row('/game_psevdonim')
    keyboard.row('/game_nim')
    keyboard.row('/game_krestikinoliki')
    bot.send_message(message.from_user.id, "Привет! Вот мои мини-игры", reply_markup=keyboard)


@bot.message_handler(commands=['game_krestikinoliki'])
def game_krestikinoliki(message):
    global mmm
    global current

    bot.send_message(message.from_user.id, "Игра Крестики-Нолики")
    bot.send_message(message.from_user.id, "Для начала напомню правила\n")
    bot.send_message(message.from_user.id, "Игроки по очереди ставят на свободные клетки поля 3х3"
                                           " знаки (один всегда крестики,"
                                           " другой всегда нолики). Первый, выстроивший в ряд 3"
                                           " своих фигуры по вертикали,"
                                           "горизонтали или диагонали, выигрывает. Первый ход делает игрок, ставящий "
                                           "крестики. "
                                           "Обычно по завершении партии выигравшая сторона зачёркивает "
                                           "чертой свои три знака (нолика или крестика),"
                                           " составляющих сплошной ряд.")
    # логика игры

    mmm = [
        ["⬜", "⬜", "⬜"],
        ["⬜", "⬜", "⬜"],
        ["⬜", "⬜", "⬜"]
    ]

    keyboard = types.InlineKeyboardMarkup()
    key = types.InlineKeyboardButton(text=mmm[0][0],
                                     callback_data=f'krest,0,0,{message.chat.id}')
    key1 = types.InlineKeyboardButton(text=mmm[0][1],
                                      callback_data=f'krest,0,1,{message.chat.id}')
    key2 = types.InlineKeyboardButton(text=mmm[0][2],
                                      callback_data=f'krest,0,2,{message.chat.id}')
    key3 = types.InlineKeyboardButton(text=mmm[1][0],
                                      callback_data=f'krest,1,0,{message.chat.id}')
    key4 = types.InlineKeyboardButton(text=mmm[1][1],
                                      callback_data=f'krest,1,1,{message.chat.id}')
    key5 = types.InlineKeyboardButton(text=mmm[1][2],
                                      callback_data=f'krest,1,2,{message.chat.id}')
    key6 = types.InlineKeyboardButton(text=mmm[2][0],
                                      callback_data=f'krest,2,0,{message.chat.id}')
    key7 = types.InlineKeyboardButton(text=mmm[2][1],
                                      callback_data=f'krest,2,1,{message.chat.id}')
    key8 = types.InlineKeyboardButton(text=mmm[2][2],
                                      callback_data=f'krest,2,2,{message.chat.id}')
    current = "X"
    keyboard.row(key, key1, key2)
    keyboard.row(key3, key4, key5)
    keyboard.row(key6, key7, key8)
    bot.send_message(message.from_user.id, "Ходи!", reply_markup=keyboard)


def do(message):
    global nnn

    kkk = int(message.text)
    if kkk > 3 or nnn < kkk or kkk <= 0:
        bot.send_message(message.from_user.id, "Ошибка!")
        a = bot.send_message(message.from_user.id, "Повторите ход!")
        bot.register_next_step_handler(a, do)
        return
    nnn -= kkk
    if nnn == 0:
        bot.send_message(message.from_user.id, "Игрок выиграл!")
        return
    if nnn <= 3:
        bot.send_message(message.from_user.id, f"Компьютер взял {nnn} камней и победил!")
        return
    elif nnn % 3 == 2:
        bot.send_message(message.from_user.id, f"Компьютер взял 1 камень")
        nnn -= 1
        a = bot.send_message(message.from_user.id, f"Сейчас камней {nnn}, сколько хотите взять?")
        bot.register_next_step_handler(a, do)
    elif nnn % 3 == 1:
        bot.send_message(message.from_user.id, f"Компьютер взял 3 камня")
        nnn -= 3
        a = bot.send_message(message.from_user.id, f"Сейчас камней {nnn}, сколько хотите взять?")
        bot.register_next_step_handler(a, do)
    elif nnn % 3 == 0:
        bot.send_message(message.from_user.id, f"Компьютер взял 2 камня")
        nnn -= 2
        a = bot.send_message(message.from_user.id, f"Сейчас камней {nnn}, сколько хотите взять?")
        bot.register_next_step_handler(a, do)


@bot.message_handler(commands=['game_psevdonim'])
def game_psevdonim(message):
    global nnn

    bot.send_message(message.from_user.id, "Игра Псевдоним")
    bot.send_message(message.from_user.id, "Для начала напомню правила\n")
    bot.send_message(message.from_user.id, "Игра заключается в следующем: в одной куче лежит N камней, каждому из "
                                           "двух игроков разрешается по очереди брать не более 3 камней. Выигрывает "
                                           "тот, "
                                           "кто возьмёт последний. Количество камней "
                                           "должно задаваться перед началом новой игры. Оставшееся количество камней "
                                           "на столе "
                                           "должно отображаться на экране. Пользователь играет "
                                           "против компьютера и выбирает, "
                                           "сколько камней хочет взять. Игрок "
                                           "ходит первым.")
    # логика игры
    nnn = random.randint(10, 20)
    a = bot.send_message(message.from_user.id, f"Сейчас камней {nnn}, сколько хотите взять?")
    bot.register_next_step_handler(a, do)


hodi = 10


@bot.message_handler(commands=['game_nim'])
def game_nim(message):
    global hodi
    global xxx
    global y
    global z

    bot.send_message(message.from_user.id, "Игра Ним")
    bot.send_message(message.from_user.id, "Для начала напомню правила\n")
    bot.send_message(message.from_user.id, "В начале игры генерируется число X и выводится на экран. Также создаются"
                                           " две кнопки, одна из которых отвечает за "
                                           "увеличение этого числа на Y, а вторая — за "
                                           "уменьшение числа на Z. X, Y, Z — случайные "
                                           "целые числа. Задача игрока — с помощью этих двух "
                                           "кнопок за 10 ходов привести значение Х к 0. Количество"
                                           "оставшихся ходов выводится на экран")
    # логика игры
    hodi = 10
    xxx = random.randint(10, 50)
    y = random.randint(1, 20)
    z = random.randint(1, 20)
    z *= -1

    keyboard = types.InlineKeyboardMarkup()
    key = types.InlineKeyboardButton(text="+" + str(y),
                                     callback_data=f'nim,{y},{message.from_user.id}')
    key1 = types.InlineKeyboardButton(text=str(z),
                                      callback_data=f'nim,{z},{message.from_user.id}')
    keyboard.row(key)
    keyboard.row(key1)

    bot.send_message(message.from_user.id, f"Сейчас число {xxx}, осталось ходов: {hodi}. Выберите ход ",
                     reply_markup=keyboard)
    # bot.register_next_step_handler(a, game_nim)


def job():
    with open('subscribers.json') as f:
        data = json.load(f)
    for k in data["users"]:
        if data["users"][k]:
            data = get_data_from_igromania()
            data1 = get_data_from_stopgame()
            data2 = get_data_from_gamemag()

            k = 0

            bot.send_message(str(k), "Последние новости из ресурса https://www.igromania.ru/news/")
            for i in data:
                bot.send_message(str(k), i[0])

                keyboard = types.InlineKeyboardMarkup()
                key = types.InlineKeyboardButton(text='Добавить в избранное',
                                                 callback_data=f'izbrannoe,{str(k)},{k}')
                keyboard.row(key)

                bot.send_message(str(k), "Подробнее: \n" + i[1], reply_markup=keyboard)
                k += 1

            bot.send_message(str(k), "Последние новости из ресурса https://stopgame.ru/news")
            for i in data1:
                bot.send_message(str(k), i[0])

                keyboard = types.InlineKeyboardMarkup()
                key = types.InlineKeyboardButton(text='Добавить в избранное',
                                                 callback_data=f'izbrannoe,{str(k)},{k}')
                keyboard.row(key)

                bot.send_message(str(k), "Подробнее: \n" + i[1], reply_markup=keyboard)
                k += 1

            bot.send_message(str(k), "Последние новости из ресурса https://gamemag.ru/news")
            for i in data2:
                bot.send_message(str(k), i[0])

                keyboard = types.InlineKeyboardMarkup()
                key = types.InlineKeyboardButton(text='Добавить в избранное',
                                                 callback_data=f'izbrannoe,{str(k)},{k}')
                keyboard.row(key)

                bot.send_message(str(k), "Подробнее: \n" + i[1], reply_markup=keyboard)
                k += 1


schedule.every(12).hours.do(job)


def task1():
    while True:
        time.sleep(3600)
        schedule.run_pending()


def task2():
    bot.polling(none_stop=True)


e1 = threading.Event()
e2 = threading.Event()

# init threads
t1 = threading.Thread(target=task1)
t2 = threading.Thread(target=task2)

# start threads
t1.start()
t2.start()

e1.set()  # initiate the first event

# join threads to the main thread
t1.join()
t2.join()
